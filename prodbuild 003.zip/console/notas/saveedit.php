<?php
  $conn = mysqli_connect("oneworldacademymz.com", "oneworv0_admin", "admin", "oneworv0_students") or die ('I cannot connect to the database.');

  $coll=$_POST['col'];
  $idd=$_POST['id'];
  $vall=$_POST['val'];
  $sc=$_POST['sc'];
  $sd=$_POST['sd'];

  $disc = $sd.$sc;

  // echo "$idd" + $idd + "<br>";
  // echo "$vall" + $vall + "<br>";
  // echo "$sc " + $sc + "<br>";
  // echo "$sd " + $sd + "<br>";
  // echo "$coll" + $coll + "<br>";




  $sql= mysqli_query($conn, "UPDATE $disc SET $coll=$vall WHERE nome_id=$idd");

?>

<?php
  // mysqli_connect() function opens a new connection to the MySQL server.
  $conn = mysqli_connect("127.0.0.1", "root", "", "database1");
  session_start();// Starting Session

  // Storing Session
  $user_check = $_SESSION['login_user'];

  // SQL Query To Fetch Complete Information Of User
  $query = "SELECT * from students where username = '$user_check'";
  $ses_sql = mysqli_query($conn, $query);
  $row = mysqli_fetch_assoc($ses_sql);

  # Get User Details
  $ls__id = $row['id'];
  $ls__first_name = $row['first_name'];
  $ls__last_name = $row['last_name'];

?>

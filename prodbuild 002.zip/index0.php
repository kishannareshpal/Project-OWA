<!DOCTYPE html>
<html lang="en">
<head>
  <!-- TODO: Add essential meta tags later -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Project OWA (Alpha)</title>

  <!-- hosted css's -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.3.0/semantic.min.css">
  <link rel="stylesheet" href="required/js/material-components-web/dist/material-components-web.min.css">
  <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.teal-blue.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cinzel+Decorative|Open+Sans|Lobster">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="required/css/app.css">


</head>
<body class="backdrop">

  <!-- Page Body -->
  <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
    <header style="background-color: rgba(72, 130, 251, 0.71)" class="mdl-layout__header mdl-layout__header--scroll mdl-layout__header--transparent"> <!-- himage -->
      <!-- page header -->
      <div class="show-on-large hide-on-med-and-down">
        <div style="height: 400px;" class="mdl-layout__header-row">
          <!-- Title -->
          <span style="margin-top: 120px; "><img src="images/logo.png" width='400px'></span>

          <span style="margin-top: 70px;" class="mdl-layout-title">
            <span style="font-family: 'Cinzel Decorative', cursive; font-size: 40pt; text-shadow: 3px 3px rgba(43, 43, 43, 0.8);">
              <strong>
                One<br>
                World<br>
                Academy
              </strong>
            </span>
            <h3 style="font-family: 'Cinzel Decorative', cursive; margin-bottom: 0px; text-shadow: 1px 1px rgba(43, 43, 43, 0.8);" class="mdl-layout-title"><strong>Elementary School</strong></h3>
          </span>
          <!-- Add spacer, to align navigation to the right -->
          <div class="mdl-layout-spacer"></div>
        </div>
      </div>

      <div class="show-on-medium-and-down hide-on-med-and-up">
        <div style="height: 100px; padding-left: 5px" class="mdl-layout__header-row">
          <div class="mdl-layout-spacer"></div>
          <!-- Title -->
          <span><img src="images/logo.png" width='50px'></span>
          <span class="mdl-layout-title">
            <span style="font-family: 'Cinzel Decorative', cursive; font-size: 16px;">
              <strong>One World Academy</strong>
            </span>
            <h3 style="font-family: 'Cinzel Decorative', cursive; font-size: 12px; margin-bottom: 0px; margin-top: 0px" class="mdl-layout-title"><strong>Elementary School</strong></h3>
          </span>
          <!-- Add spacer, to align navigation to the right -->
          <div class="mdl-layout-spacer"></div>
        </div>
      </div>

    </header>

    <main class="mdl-layout__content">
      <!-- page content -->
      <div class="mdl-grid">
        <div class="mdl-layout-spacer"></div>
        <div style="margin-top: 90px" class="mdl-cell mdl-cell--10-col">
          <nav class="mdl-navigation mdl-shadow--2dp mdl-color--grey-50" style="padding: 20px; margin-bottom: 30px; border-radius: 5px">
            <div class="mdl-grid">
              <a href='' style="color: white; margin: 5px; border-radius: 7px;" class="mdl-button mdl-js-button mdl-color--blue-500">Home</a>
              <a href='' style="color: grey; margin: 5px; border-radius: 7px" class="mdl-button mdl-js-button mdl-color--blue-50">Staff</a>
              <a href='' style="color: grey; margin: 5px; border-radius: 7px" class="mdl-button mdl-js-button mdl-color--blue-50">Get Involved</a>
              <a href='' style="color: grey; margin: 5px; border-radius: 7px" class="mdl-button mdl-js-button mdl-color--blue-50">Contacts</a>
              <a href="about/" style="color: grey; margin: 5px; border-radius: 7px" class="mdl-button mdl-js-button mdl-color--blue-50">About Us</a>
              <a href='parents/' style="color: grey; margin: 5px; border-radius: 7px" class="mdl-button mdl-js-button mdl-color--orange-50">Parents Portal</a>
            </div>
          </nav>

          <div style="width: 100%; border-radius: 10px" class="mdl-card mdl-shadow--2dp">
            <div style="width: 100%" class="mdl-card__supporting-text">
              <!-- actual page content -->
              <div style="height: 300px" class="siema mdl-shadow--8dp">
                <img width="100%" height="100%" src="images/1.jpg" alt="">
                <img width="100%" height="100%" src="images/2.jpg" alt="">
                <img width="100%" height="100%" src="images/3.jpg" alt="">
                <img width="100%" height="100%" src="images/4.jpg" alt="">
                <img width="100%" height="100%" src="images/6.jpg" alt="">
                <img width="100%" height="100%" src="images/7.jpg" alt="">
                <img width="100%" height="100%" src="images/sd-1.png" alt="">


              </div>

                <div class="mdl-layout-spacer"></div>
                  <div style="padding: 15px; overflow-x: auto;">
                    <h2 style="margin-top: 30px; font-size: 32px; padding: 10px; border-radius: 5px 50px 5px 5px" class="bg-grad mdl-color-text--white"><strong>_Our School</strong></h2>
                    <p class="mdl-color-text--grey-400">Monday, February 26th, 2018</p>

                    <!-- ... content ... -->
                    <span style="font-size: 18px; font-family: 'Open Sans', sans-serif;" class="flow-text">
                      Welcome to One World Academy!<br><br>
                      We are off and running with the 2018 academic year and we couldn’t be more motivated to continue with our mission of providing a top notch, international quality education at a price that the working-class Mozambicans can afford. We are currently in our 4th year of existence at One World Academy, this year offering <i>bilingual education</i> for <span style="padding: 5px;" class="mdl-shadow--2dp mdl-color--grey-100 mdl-color-text--black hoverable">kindergarten</span>, <span style="padding: 5px;" class="mdl-shadow--2dp mdl-color--grey-100 mdl-color-text--black hoverable">1st</span>, <span style="padding: 5px;" class="hoverable mdl-shadow--2dp mdl-color--grey-100 mdl-color-text--black">2nd</span>, <span style="padding: 5px;" class="hoverable mdl-shadow--2dp mdl-color--grey-100 mdl-color-text--black">3rd</span> and
                      <span style="padding: 5px;" class="hoverable mdl-shadow--2dp mdl-color--grey-100 mdl-color-text--black">4th grades</span>.
                      With every passing year we add a new grade which allows us to ensure that One World Academy can maintain the quality that we have become so well known for. <br> <br>
                      The school curriculum is based on the Mozambican National Curriculum which is taught in Portuguese during the morning period. In the afternoons a new team of teachers arrive, and the language of instruction for all classes and activities changes to English.  At One World Academy we are committed to delivering strong academic achievement with a focus on literacy, numeracy and technology. We use an integrated inquiry approach to our academic planning which seeks to links curriculum content across different subjects in meaningful ways for our students. <br><br>
                      Learning at One World Academy is underpinned by our values of <span style="padding: 5px;" class="mdl-shadow--2dp mdl-color--green-100 mdl-color-text--white">Respect</span>, <span style="padding: 5px;" class="mdl-shadow--2dp mdl-color--orange-100 mdl-color-text--white">Excelence</span> and <span style="padding: 5px;" class="mdl-shadow--2dp mdl-color--red-100 mdl-color-text--white">Responsibility</span>. We use these values to guide our behaviors and develop respectful relationships and effective learning.<br><br>
                      One World Academy offers a range of special programs for students, these include:

                      <!-- One World Academy offers a range of special programs for students, these include:
                        •	Bilingual Education
                        •	Visual and Performing arts
                        •	Dance instruction
                        •	Choir
                        •	Sporting teams
                        •	Computers and IT (coming soon) -->
                    </span>

                    <div class="mdl-grid">
                      <div class="mdl-cell mdl-cell--6-col mdl-cell--12-col-tablet mdl-cell--12-col-phone">
                        <div class="mdc-card hoverable" style="margin: 10px; background-color: #f5c25e; width: 100%; padding: 50px; text-align: center; font-size: 28px; color: white; font-family: lobster; line-height:1.5">
                          Bilingual education
                        </div>
                      </div>
                      <div class="mdl-cell mdl-cell--6-col mdl-cell--12-col-tablet mdl-cell--12-col-phone">
                        <div class="mdc-card hoverable" style="margin: 10px; background-color: #8A1C7C; width: 100%; padding: 50px; text-align: center; font-size: 28px; color: white; font-family: lobster; line-height:1.5">
                          Visual and Performing arts
                        </div>
                      </div>
                      <div class="mdl-cell mdl-cell--6-col mdl-cell--12-col-tablet mdl-cell--12-col-phone">
                        <div class="mdc-card hoverable" style="margin: 10px; background-color: #DA4167; width: 100%; padding: 50px; text-align: center; font-size: 28px; color: white; font-family: lobster; line-height:1.5">
                          Dance instruction
                        </div>
                      </div>
                      <div class="mdl-cell mdl-cell--6-col mdl-cell--12-col-tablet mdl-cell--12-col-phone">
                        <div class="mdc-card hoverable" style="margin: 10px; background-color: #F0BCD4; width: 100%; padding: 50px; text-align: center; font-size: 28px; color: white; font-family: lobster; line-height:1.5">
                          Choir
                        </div>
                      </div>
                      <div class="mdl-cell mdl-cell--6-col mdl-cell--12-col-tablet mdl-cell--12-col-phone">
                        <div class="mdc-card hoverable" style="margin: 10px; background-color: #899D78; width: 100%; padding: 50px; text-align: center; font-size: 28px; color: white; font-family: lobster; line-height:1.5">
                          Sporting teams
                        </div>
                      </div>
                      <div class="mdl-cell mdl-cell--6-col mdl-cell--12-col-tablet mdl-cell--12-col-phone">
                        <div class="mdc-card hoverable" style="margin: 10px; background-color: #41afd7; width: 100%; padding: 50px; text-align: center; font-size: 28px; color: white; font-family: lobster; line-height:1.5">
                          Computers and IT
                        </div>
                      </div>






                    </div>

                    <span style="font-size: 18px; font-family: 'Open Sans', sans-serif; line-height: 1.6;">
                      One World Academy is very much a community school. We encourage and support a high level of parent engagement in our school life. We have a very active school board who supports the school in many ways.
                      We welcome you to reach out to us or even visit our school to talk with us about our programs, our vision moving forward and most importantly how we can provide the best learning environment for our students.
                      <p style="text-align: right" class="mdl-color-text--grey-400"><i>• Shaun Bisset, Founder and Owner</i></p>
                    </span>

                  </div>
                <div class="mdl-layout-spacer"></div>



            </div>
          </div>

        </div>
        <div class="mdl-layout-spacer"></div>
      </div>

      <footer style="text-align: center" class="mdl-mega-footer">
        <div class="mdl-mega-footer__middle-section">
        </div>

        <div class="mdl-mega-footer__bottom-section">
          <div class="mdl-layout-spacer"></div>
          <div><script>document.write((new Date()).getFullYear())</script> © One World Academy Elementary School</div>
          <p>Maxixe, Mozambique</p>
          <div>All rights reserved.</div>
          <p class="mdl-color-text--red-400">Notice: This web app is under development. Build_nr. A<script>document.write(localStorage.getItem("app_version_owa"))</script></p>
          <div class="ui buttons">
            <button class="ui disabled button">Change to</button>
            <button class="ui icon button">
              Portuguese
            </button>
          </div>
          <div class="mdl-layout-spacer"></div>
        </div>
      </footer>
    </main>

  </div>

  <!-- Imports -->
  <script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script defer src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.3.0/semantic.min.js"></script>
  <script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
  <script defer src="required/js/material-components-web/dist/material-components-web.min.js"></script>
  <script defer src="required/js/siema.min.js"></script>
  <?php include './required/php/app.php' ?>
  <script defer src="required/js/app.js"></script>


</body>
</html>

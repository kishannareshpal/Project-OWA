$(document).ready(function(){
  // # Alpha Version Logger
  localStorage.setItem('app_version_owa', parseInt(localStorage.getItem("app_version_owa"))+1)

  // # Image slideshow
  // const siema = new Siema({
  //   selector: '.siema',
  //   duration: 800,
  //   easing: 'ease-out',
  //   perPage: 1,
  //   startIndex: 0,
  //   draggable: true,
  //   multipleDrag: true,
  //   threshold: 20,
  //   loop: true,
  //   rtl: false,
  //   // onInit: () => {},
  //   // onChange: () => {},
  // });

});

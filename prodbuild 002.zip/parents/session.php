<?php
  // mysqli_connect() function opens a new connection to the MySQL server.
  $conn = mysqli_connect("oneworldacademymz.com", "oneworv0_admin", "admin", "oneworv0_students") or die ('I cannot connect to the database.');
  session_start();// Starting Session

  // Storing Session
  $user_check = $_SESSION['login_user'];

  // SQL Query To Fetch PROFILE Information Of User
  $query = "SELECT * from profiles where username = '$user_check'";
  $ses_sql = mysqli_query($conn, $query);
  $row = mysqli_fetch_assoc($ses_sql);

  # Get User Details
  $ls__id = $row['id'];
  $ls__first_name = $row['first_name'];
  $ls__last_name = $row['last_name'];
  $ls__grade = $row['grade'];

  // SQL Query To Fetch MENSALIDADE Information Of User
  $query = "SELECT * FROM mensalidades WHERE id = $ls__id AND payment_year=".date('Y');
  $ses_sql = mysqli_query($conn, $query);
  @$row = mysqli_fetch_assoc($ses_sql);

  $ls__fev = $row['fev'];
  $ls__mar = $row['mar'];
  $ls__abr = $row['abr'];
  $ls__mai = $row['mai'];
  $ls__jun = $row['jun'];
  $ls__jul = $row['jul'];
  $ls__ago = $row['ago'];
  $ls__set = $row['sete'];
  $ls__out = $row['outu'];
  $ls__nov = $row['nov'];


  // // SERIALIZATION DOWN
  // /////////////////////
  // $my_array = array("Joe", "Bloggs", "22, Letsby Avenue");
  //
  // /// Serialize Array
  // $my_array = serialize($my_array);
  //
  // /// Add to MySQL database table
  // $query = "INSERT INTO artesvisuais_1a (id, segundoTrim) VALUES ('4', '$my_array')";
  // mysqli_query($conn, $query);
  // mysqli_fetch_assoc($ses_sql);
  //
  //   /// Retrieve array
  // $query = "SELECT segundoTrim FROM artesvisuais_1a WHERE id=4 ";
  // $snglQuery = $conn->query($query);
  // $row = $snglQuery->fetch_assoc();
  // $member = $row["segundoTrim"];
  // /// Retrieve array data and structure with unserialize()
  // $member = unserialize($member);
  // print_r($member[0]);
?>

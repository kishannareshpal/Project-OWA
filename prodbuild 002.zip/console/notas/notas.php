<?php
$conn = mysqli_connect("oneworldacademymz.com", "oneworv0_admin", "admin", "oneworv0_students") or die ('I cannot connect to the database.');

// $value=$_POST['value'];
// // $theID=$_POST['theID'];
// // $field=$_POST['field'];
// var_dump($value);
//
// $sql= mysqli_query($conn, "UPDATE artesvisuais_1a SET primeiroTrim=$value");

  $sql = "SELECT ef.*, pf.username FROM port_1a as ef, profiles as pf WHERE ef.nome_id = pf.id";
  // $sql = "SELECT * FROM educacaofisica_4a";
  $qe = mysqli_query($conn, $sql);
  $row = mysqli_fetch_assoc($qe);

?>

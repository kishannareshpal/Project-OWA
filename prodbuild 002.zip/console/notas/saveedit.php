<?php
$conn = mysqli_connect("oneworldacademymz.com", "oneworv0_admin", "admin", "oneworv0_students") or die ('I cannot connect to the database.');

$coll=$_POST['col'];
$idd=$_POST['id'];
$vall=$_POST['val'];

$sql= mysqli_query($conn, "UPDATE educacaofisica_4a SET $coll=$vall WHERE nome=$idd");

?>
